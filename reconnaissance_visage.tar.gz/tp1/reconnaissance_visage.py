#!/usr/bin/python
# -*- coding: latin-1 -*-

import sys
import cv2
import numpy as np

face_cascade_name="./haarcascade_frontalface_alt.xml"
nombre_de_classes=0


#Lecture des données
def read_data(filename, separator = ';') :

    images_vector=[]
    labels_vector=[]
    
    with open(filename, 'rb') as f:
        for line in f.readlines() :           
            line_splitted=line.split(';')
            path=line_splitted[0]
            classlabel=line_splitted[1]
            if len(path.strip()) != 0  and len(classlabel.strip()) != 0 :
                images_vector.append(cv2.imread(path,0))
                labels_vector.append(int(classlabel)) 
    return images_vector, labels_vector


#Distance entre les elements d un vecteur d'histogramme et un histogramme donné
def dist_vec_to_set(train_model, test_model_histogram, distance_type) :
    
    distances=[]
    #Nous cacuons plusieurs types de distances afin de comparer les résutats obtenus avec
    #chacune d'elle
    for i in range(len(train_model)) :

        if int(distance_type) == 1 :
            distances.append(cv2.compareHist(train_model[i], test_model_histogram,cv2.cv.CV_COMP_CHISQR))    # chi2
        elif int(distance_type) == 2 :
            distances.append(cv2.compareHist(train_model[i], test_model_histogram,cv2.cv.CV_COMP_BHATTACHARYYA)) #bhattacharyya
        else :
            print ("error the distance type you entered is not valid! Choose a distance between 1 ou 2")
            sys.exit(0)    

    return distances





#Prédiction de classe par l'algorithme du KNN
def KNN(train_model, test_model_histogram, training_labels, k, distance_type) :
    #print test_model_histogram
    #distance entre un histogramme de test et l'ensemble des histogrammes d'entrainement
    distances_tab=[]
    distances_tab = dist_vec_to_set(train_model, test_model_histogram,distance_type)
    #for i in range(len(distances_tab)) :
        #print "distances_tab[",i,"] " ,distances_tab[i] 
    #print "-------------------------------------------------------------------------"

    sorted_distances={}
    #sorted_distances = distances_tab
    #print "distances_tab",distances_tab
    #print "\n\n"

    #tri du tableau de distances obtenu
    #sorted_distances.sort()
    for i in range(len(distances_tab)) :        
        sorted_distances[i]=distances_tab[i]   
        
        
    sorted_distances = sorted([(v, u) for (u, v) in sorted_distances.items()])
    #print sorted_distances
    #print sorted_distances
    #print "sorted distances",sorted_distances
    #print "test avant"

    #stockage des k meilleur résutats
    knn=[]

    #for i in range(k) :
        #if distance_type == 1 or distance_type == 3 :
            #pos=distances_tab.index(sorted_distances[len(sorted_distances)- 1 - i])
            #knn.append(training_labels[pos])        
        #if distance_type == 2 or distance_type == 4 :
            #print "distance type = 2 ou 4"
            #pos=distances_tab.index(sorted_distances[i])
            #knn.append(training_labels[pos])

    #sorted_distances_k=sorted_distances
    #print sorted_distances_k
    #print "sadjabdkjv----------------------------------------------------"
            
    #for i in range(len(sorted_distances_k)) :
        #min_value=sorted_distances[i]
        #position=0
        #for j in range(len(distances_tab)) :
            #if distances_tab[j]==min_value :
                #position=j
                #del distances_tab[j]
                #break
            #pos=training_labels[position]
            #knn.append(pos)
                    
    #print training_labels
    #knn.sort()
    #print sorted_distances[3][1]
    #print "k : ",k

    for i in range(k) :
        knn.append(training_labels[sorted_distances[i][1]])
        #print training_labels[sorted_distances[i][1]]
    knn.sort()
    #print knn
    #print "\nknn: \t",knn


    #Determination du nombre de classes
    compteur=[]
    #print "test"
    
    for i in range(k) :
            compteur.append(0)    

    for i in range(k) :
        for j in range(len(knn)) :
            if knn[j]==knn[i] :
                compteur[i]=compteur[i]+1
        i = i + compteur[i] - 1

    #Determination de la classe majoritaire
    max_index = 0
    for m in range(k) :
        if compteur[max_index] < compteur[m] :
            max_index = m
        
    
    classe = knn[max_index]

    return classe




'''

// detection de visage pour la base d'apprentissage et de test
Mat detection(Mat frame) {

    vector<Rect> faces;
    Mat frame_gray;

    //conversion en image en niveau de gris
    if(frame.channels() == 3){
        cvtColor(frame, frame_gray, COLOR_BGR2GRAY);
    } else
        frame_gray = frame;


    //detection des faces
    face_cascade.detectMultiScale(frame_gray, faces, 1.01, 1, 0, Size(30, 30));

    //Normalisation de l'image
    //equalizeHist(frame_gray, frame_gray);

    //récuperation du visage détecté
    Mat face_detected;
    if (faces.size() == 0) {
        face_detected = frame_gray;
    } else {
        face_detected = frame_gray(faces[0]);
    }

    //Redimensionnement des images
    resize(face_detected, face_detected, Size(90, 120), 1.0, 1.0, INTER_CUBIC);
    return face_detected;
}




'''
#Calcul du taux de précision
def bon_taux(conf_mat) :
    taux = 0
    somme_diag = 0
    somme_tot = 0
    #print "Dans la methode bon_taux"

    #sommation des éléments de la diagonale et division par
    #la somme de tous les éléments de la matrice
    for i in range(nombre_de_classes) :
        #for (int i = 0; i < nb_classes; i++)
        for j in range(nombre_de_classes) :
        #for (int j = 0; j < nb_classes; j++) 
            if i == j : 
                somme_diag += conf_mat[i][j]
                #print conf_mat[i][j]
            
            somme_tot += conf_mat[i][j]
    #print "somme_diag : ",somme_diag
    #print "somme_tot : ",somme_tot
        
    
    taux = float(somme_diag)/float(somme_tot)   
    #print "taux : ", taux
    return somme_diag, somme_tot, taux






if __name__ == "__main__" :
    
    
    print ("\n\tSysteme de reconnaissance de visages par LBPHFaceRecognizer et KNN\n\tAuteurs : Pierre Rubens MILORME, Perrault ANDRE, Biakota Bombia Herbert CEPHAS\n")
    #Demande du type de distance a utiliser
    print ("Entrez le nombre correspondant au type de distance que vous voulez utiliser :")
    print (" 1 - Distance de CHI2")
    print (" 2 - Distance de Bhattacharyya\n")

    #Lecture de la distance
    distance_type=input("Choix(entre 1 ou 2) : ") 

    #demande de la valeur de k pour l'algorithme du Knn
    k = int(input("Entrez la valeur de K pour le KNN : "))
    
    if len(sys.argv) < 2 :
        print ("usage: ", sys.argv[0], " <apprentissage.txt> <test.txt> ")
        sys.exit(0)          

    #Chargement des descripteurs
    face_cascade = cv2.CascadeClassifier(face_cascade_name)

    #Lire les fichiers descriptifs de la base d'apprentissage et de test
    training_file = sys.argv[1]
    test_file = sys.argv[2]

        #vecteurs images apprentissage et test.
    training_images=[]
    test_images=[]

    #vecteurs de labels pour les bases apprentissage et test.
    training_labels=[]
    test_labels=[]

    #Lecture des donnnees
    try:
            training_data=read_data(training_file)
            training_images=training_data[0]
            training_labels=training_data[1]
    except IOError:
            print ("Could not read file:")
            sys.exit(0)
        

    try:
            test_data=read_data(test_file)
            test_images=test_data[0]
            test_labels=test_data[1]
    except IOError:
            print ("Could not read file:")
            sys.exit(0)
          
        #Application du LBP à la base d'apprentissage      
        #Application du LBP à la base d'apprentissage
    training_model=cv2.createLBPHFaceRecognizer()
    training_model.train(training_images, np.array(training_labels))
        
    test_model=cv2.createLBPHFaceRecognizer()
    test_model.train(test_images, np.array(test_labels))
            
        #Récupération des histogrammes
    train_histograms=training_model.getMatVector("histograms")
    test_histograms=test_model.getMatVector("histograms") 
        #print train_histograms[0]


    print ("\nEn attente des calculs...")
        #prédiction des labels
    predicted_labels=[]
        
    for i in range(len(test_histograms)) :
            #print "images_test", i
            #print test_histograms[i]
        predicted_labels.append(KNN(train_histograms, test_histograms[i], training_labels, k, distance_type))    
        #print "test labels"
        #print test_labels
        #print "predicted_labels"
        #print predicted_labels    

        
            
        #déterminantion du nombre de classes        
        nombre_de_classes=len(sorted(list(set(test_labels))))
        
        #creation de la matrice de confusion    
        matrice_de_confusion=[]
        for i in range(nombre_de_classes):
            matrice_de_confusion.append([0] * nombre_de_classes)
            
        #print "\n"
        #for i in range(len(matrice_de_confusion)):
            #print matrice_de_confusion[i]   
        
           

        #remplissage matrice de confusion
        for i in range(len(test_images)) :
            matrice_de_confusion[test_labels[i]][predicted_labels[i]]+=1
            
        
        print ("\n")
        for i in range(len(matrice_de_confusion)):
            print (matrice_de_confusion[i]   )
            
        #for (size_t m = 0; m < test_images.size(); m++) {
            #confusion_matrix[test_labels[m]][predicted_labels[m]]++;
        #}

        #Affichage matrice de confusion
        #cout << endl << "Matrice de confusion" << endl;
        #for (int a = 0; a < nb_classes; a++) {
            #for (int b = 0; b < nb_classes; b++) {

                #cout << confusion_matrix[a][b] << " ";
            #}
            #cout << endl;

        #}
        resultat=bon_taux(matrice_de_confusion)
        #affichage taux de précision
        print ("\n\nSomme des elements sur la diagonale de la matrice(classes correctement predites) : ",resultat[0] )
        print ("Somme totale des elements de la matrice : ",resultat[1])
        print ("\nle taux de précision est : ",  resultat[2] * 100, "%")

     



